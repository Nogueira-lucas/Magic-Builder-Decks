import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { MagicService } from './services/card.service';
import { Card } from 'mtgsdk-ts';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  public cards$: Observable<Card[]>;

  constructor(private cardService: MagicService) {}

  ngOnInit() {
    console.log('inicio request');

    this.cards$ = this.cardService.getCardList();
  }


}
