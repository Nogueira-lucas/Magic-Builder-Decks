import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Card } from '../../../node_modules/mtgsdk-ts';

const URL = 'https://api.magicthegathering.io/v1/cards';

@Injectable({
  providedIn: 'root'
})
export class MagicService {


  constructor(private http: HttpClient) {
  }

  getCardList() {
    return this.http.get<Card[]>(URL);
  }

}
